
# Personal Portfolio Website

Video URL = https://youtu.be/QYZGtp9pwyk

This is a Personal Portfolio Website, which contains a brief introduction about me and 
what i do.

 
 
 portfolio site is an extension of a freelancer's (or company's) résumé. It provides a convenient way for potential clients to view your work while also allowing you to expand on your skills and services. This, however, isn't the ultimate purpose of a portfolio website.

THe Website is Responsive. So, It adjusts to the any resolution. Without any bug.

 The Technologies I've used for this project are:-
 HTML,
 CSS
 and JAVA SCRIPT






